//
//  ViewController.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let animator = LYTransitionAnimator()
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func clickAction() {
        let popUpVC = LYPopUpViewController(nibName: "LYPopUpViewController",bundle: nil)
        popUpVC.transitioningDelegate = self
        presentViewController(popUpVC, animated: true, completion: nil)
    }

}

extension ViewController:UIViewControllerTransitioningDelegate {
    func animationControllerForPresentedController(presented: UIViewController, presentingController presenting: UIViewController, sourceController source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        animator.presenting = true
        animator.originFrame = button.superview!.convertRect(button.frame, toView: nil)
        return animator
    }
    
    func animationControllerForDismissedController(dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        animator.presenting = false
        return animator
    }
}

