//
//  LYPopUpViewController.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

class LYPopUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.layer.cornerRadius = 3
        view.layer.shadowOpacity = 0.3
        view.layer.shadowOffset = CGSizeMake(3, 3)
    }
    @IBAction func dismissAction(sender:UIButton) {
        UIView.animateWithDuration(0.25, animations: { 
            sender.transform = CGAffineTransformMakeScale(0.1, 0.1)
            }) { (_) in
                UIView.animateWithDuration(0.25, animations: { 
                    self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
                    }, completion: { (_) in
                        self.dismissViewControllerAnimated(true, completion: nil)
                })
        }
    }

}

extension LYPopUpViewController:UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        
    }
}
