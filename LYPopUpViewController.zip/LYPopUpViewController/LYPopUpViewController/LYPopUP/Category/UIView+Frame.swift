//
//  UIView+Frame.swift
//  NewFreshBeen
//
//  Created by 吕师 on 16/6/6.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

extension UIView {

    var x: CGFloat {
        set {
            frame.origin.x = newValue
        }
        get {
            return frame.origin.x
        }
    }
    var y: CGFloat {
        set {
            frame.origin.y = newValue
        }
        get {
            return frame.origin.y
        }
    }
    var left: CGFloat {
        get{ return frame.origin.x }
        set{ frame.origin.x = newValue }
    }
    var right:CGFloat {
        get{ return frame.origin.x + frame.size.width }
        set{ frame.origin.x += newValue - (frame.origin.x + frame.size.width) }
    }
    
    var centerX: CGFloat {
        set { center = CGPointMake(centerX, center.y)}
        get { return center.x }
    }
    
    var centerY: CGFloat {
        set { center = CGPointMake(center.x, centerY)}
        get { return center.y }
    }
    
    var top:CGFloat {
        get{ return frame.origin.y }
        set{ frame.origin.y = newValue }
    }
    var bottom:CGFloat{
        get{ return frame.origin.y + frame.size.height }
        set{ frame.origin.y = newValue - frame.size.height }
    }
    
    var width:CGFloat {
        get{ return frame.size.width }
        set{ frame.size.width = newValue }
    }
    var height:CGFloat {
        get{ return frame.size.height }
        set{ frame.size.height = newValue }
    }
    
    var origin:CGPoint{
        get{ return frame.origin }
        set{ frame.origin = newValue}
    }
    
    var bottomRight:CGPoint{
        get{
            let x = frame.origin.x + frame.size.width;
            let y = frame.origin.y + frame.size.height;
            return CGPointMake(x, y);
        }
    }
    var bottomLeft:CGPoint{
        get{
            let x = frame.origin.x;
            let y = frame.origin.y + frame.size.height;
            return CGPointMake(x, y);
        }
    }
    var topRight:CGPoint{
        get{
            let x = frame.origin.x + frame.size.width;
            let y = frame.origin.y;
            return CGPointMake(x, y);
        }
    }
    
    func topSuperView() -> UIView {
        var topView = self.superview
        if topView == nil {
            topView = self
        } else {
            while (topView!.superview != nil) {
                topView = topView?.superview
            }
        }
        return topView!
    }
    
}