//
//  LYNibConvention.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

public protocol LYNibConvention : NSObjectProtocol {
    //类方法
    static func ly_nibId_class() -> String
    static func ly_nib_class() -> UINib
    
    //实例方法
    
    func ly_nibId_instance() -> String
    func ly_nib_instance() -> UINib
}

extension UIView : LYNibConvention {
    
    //MARK: LCNibConvention
    public func ly_nibId_instance() -> String {
        let className = NSStringFromClass(self.classForCoder)
        if className.containsString(".") {
            return className.componentsSeparatedByString(".").last!
        }else{
            return className
        }
        
    }
    
    public func ly_nib_instance() -> UINib {
        return UINib.init(nibName: self.ly_nibId_instance(), bundle: NSBundle.mainBundle())
    }
    
    
    public static func ly_nibId_class() -> String {
        let className = NSStringFromClass(self)
        if className.containsString(".") {
            return className.componentsSeparatedByString(".").last!
        }else{
            return className
        }
    }
    
    public static func ly_nib_class() -> UINib {
        return UINib.init(nibName: self.ly_nibId_class(), bundle: nil)
    }
    
    //MARK:获取nib 对象
    
    func ly_instantiateFromNib()-> UIView?{
        return self.ly_instantiateFromNibBundle(nil, owner: nil)
    }
    
    func ly_instantiateFromNibBundle(bundle:NSBundle? , owner:AnyObject?) -> UIView? {
        
        let views = self.lc_nib_instance().instantiateWithOwner(owner, options: nil)
        for view in views {
            if view.isMemberOfClass(self.classForCoder) {
                return view as? UIView
            }
        }
        
        assert(false, "Exepect file:\(self.lc_nibId_instance()).xib")
        return nil
    }
    
    
}
