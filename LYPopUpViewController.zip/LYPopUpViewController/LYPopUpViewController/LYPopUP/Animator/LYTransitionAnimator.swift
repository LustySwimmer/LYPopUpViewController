//
//  LYTransitionAnimator.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

class LYTransitionAnimator: NSObject,UIViewControllerAnimatedTransitioning {
    /** 动画时间 */
    let duration = 0.5
    /** 判断是否是present */
    var presenting = true
    /** 初始位置 */
    var originFrame = CGRectZero
    
    func transitionDuration(transitionContext: UIViewControllerContextTransitioning?) -> NSTimeInterval {
        return duration
    }
    
    func animateTransition(transitionContext: UIViewControllerContextTransitioning) {
        let containerView = transitionContext.containerView()
        let toView = transitionContext.viewControllerForKey(UITransitionContextToViewControllerKey)!
        let herbView = presenting ? toView : transitionContext.viewControllerForKey(UITransitionContextFromViewControllerKey)!
        containerView?.addSubview(toView.view)
        containerView?.bringSubviewToFront(herbView.view)
        if presenting {
            let snapView = transitionContext.viewControllerForKey(UITransitionContextFromViewControllerKey)!.view.snapshotViewAfterScreenUpdates(false)
            containerView?.insertSubview(snapView, belowSubview: herbView.view)
            let finalFrame = transitionContext.finalFrameForViewController(herbView)
            herbView.view.frame = originFrame
            herbView.view.center = CGPointMake(CGRectGetMidX(finalFrame), CGRectGetMidY(finalFrame))
            print(originFrame)
            UIView.animateWithDuration(0.25, animations: { 
                herbView.view.frame.size = CGSizeMake(finalFrame.size.width * 0.8, finalFrame.size.height * 0.8)
                herbView.view.center = CGPointMake(CGRectGetMidX(finalFrame), CGRectGetMidY(finalFrame))
                }, completion: { (_) in
                    transitionContext.completeTransition(true)
            })
        } else {
            transitionContext.completeTransition(true)
        }
        
    }

}
