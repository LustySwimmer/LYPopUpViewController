//
//  LYProgressView.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

@IBDesignable class LYProgressView: UIView {
    /** 当前进度颜色 */
    @IBInspectable var progressTint:UIColor = UIColor.colorWithCustom(29, g: 170, b: 209){
        didSet { setNeedsDisplay() }
    }
    /** 进度条轨道颜色 */
    @IBInspectable var trackTint:UIColor = UIColor.lightGrayColor() {
        didSet { setNeedsDisplay() }
    }
    /** 当前进度 */
    @IBInspectable var progress:CGFloat = 0.0 {
        didSet {
            progress > 1.0 ? 1.0 : progress
            progress < 0 ? 0 : progress
            setNeedsDisplay()
        }
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupSubView()
    }
    
    private func setupSubView() {
    
    }
    
    

    override func drawRect(rect: CGRect) {
        super.drawRect(rect)
        let progressRect = CGRectMake(0, 0, progress * width, height)
        drawWithColor(trackTint.CGColor, rect: bounds)
        drawWithColor(progressTint.CGColor, rect: progressRect)
    }
    /**
     绘制矩形区域
     
     - parameter color: 绘制颜色
     - parameter rect:  矩形
     */
    private func drawWithColor(color:CGColorRef,rect:CGRect) {
        let context = UIGraphicsGetCurrentContext()
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, x, y)
        CGContextAddRect(context, rect)
        CGContextSetFillColorWithColor(context, color)
        CGContextSetLineWidth(context, 1.0)
        CGContextFillPath(context)
    }

}
