//
//  LYButton.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

@IBDesignable class LYButton: UIButton {
    
    private var gradientLayer:CAGradientLayer?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpGradient()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpGradient()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer?.frame = bounds
    }
    
    private func setUpGradient() {
        gradientLayer = CAGradientLayer()
        gradientLayer!.frame = bounds
        gradientLayer!.locations = [NSNumber(float:0.3),NSNumber(float:0.8)]
        gradientLayer!.colors = [colorWithRGB(56, g: 195, b: 227),colorWithRGB(16, g: 156, b: 197)]
        gradientLayer!.startPoint = CGPointMake(0, 0)
        gradientLayer!.endPoint = CGPointMake(1, 0)
        layer.addSublayer(gradientLayer!)
    }
    
    private func colorWithRGB(r:CGFloat,g:CGFloat,b:CGFloat) -> AnyObject {
        return UIColor.colorWithCustom(r, g: g, b: b).CGColor as AnyObject
    }

}
