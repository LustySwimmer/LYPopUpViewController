//
//  LYTextView.swift
//  LYPopUpViewController
//
//  Created by 吕师 on 16/6/30.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

import UIKit

class LYTextView: UIView,LYNibBridge {
    
    private var timer:NSTimer?
    @IBInspectable var text:String? {
        didSet {textField.text = text}
    }
    @IBInspectable var placeholder:String? {
        didSet {textField.placeholder = placeholder}
    }
    /** 当前进度颜色 */
    @IBInspectable var progressTint:UIColor = UIColor.colorWithCustom(29, g: 170, b: 209){
        didSet { progressView.progressTint = progressTint }
    }
    /** 进度条轨道颜色 */
    @IBInspectable var trackTint:UIColor = UIColor.lightGrayColor() {
        didSet { progressView.trackTint = trackTint }
    }
    /** 当前进度 */
    @IBInspectable var progress:CGFloat = 0.0 {
        didSet {
            progressView.progress = progress
        }
    }

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var progressView:LYProgressView!
    
    func updateProgress() {
        progress += 0.01
        if progress == 1.0 {
            timer?.invalidate()
            timer = nil
        }
    }

}

extension LYTextView: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        timer = NSTimer.scheduledTimerWithTimeInterval(0.001, target: self, selector: #selector(updateProgress), userInfo: nil, repeats: true)
    }
    func textFieldDidEndEditing(textField: UITextField) {
        if !textField.hasText() {
            if timer != nil {
                timer!.invalidate()
                timer = nil
            }
            UIView.animateWithDuration(0.25) {
                dispatch_async(dispatch_get_main_queue(), {
                    self.progress = 0.0
                })
                
            }
        }
    }
}
